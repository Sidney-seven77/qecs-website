// To use a real photo: copy it into public/images, then change the path here.
// Example: hero: "/images/hero.jpg"
export const images: Record<string, string> = {
  hero: "/images/hero.svg",
  about: "/images/about.svg",
  "level-1": "/images/level-1.svg",
  "level-2": "/images/level-2.svg",
  "level-3": "/images/level-3.svg",
  "leader-1": "/images/leader-1.svg",
  "leader-2": "/images/leader-2.svg",
  "leader-3": "/images/leader-3.svg",
  "news-term-opening": "/images/news-term-opening.svg",
  "news-science-fair": "/images/news-science-fair.svg",
  "news-sports-day": "/images/news-sports-day.svg",
  "news-library-opening": "/images/news-library-opening.svg",
  "news-parents-forum": "/images/news-parents-forum.svg",
  "news-music-festival": "/images/news-music-festival.svg",
  ...Object.fromEntries(Array.from({ length: 12 }, (_, i) => [`gallery-${i + 1}`, `/images/gallery-${i + 1}.svg`])),
};
