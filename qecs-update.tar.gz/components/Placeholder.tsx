/* eslint-disable @next/next/no-img-element */
export default function Placeholder({ label, src, className = "" }: { label: string; src?: string; i?: number; className?: string }) {
  return (
    <div className={`relative overflow-hidden bg-mist ${className}`}>
      {src && <img src={src} alt={label} loading="lazy" className="absolute inset-0 h-full w-full object-cover" />}
    </div>
  );
}
